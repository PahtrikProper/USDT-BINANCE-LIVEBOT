from order_management import live_trading
from config import SYMBOL

def main():
    live_trading(SYMBOL)

if __name__ == "__main__":
    main()
