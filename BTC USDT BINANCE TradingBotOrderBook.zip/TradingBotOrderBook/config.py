import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configurable Parameters
SYMBOL = 'BTC/USDT'
ORDER_BOOK_DEPTH = 25
TRADE_AMOUNT = 200
TRADE_INTERVAL_SECONDS = 6
MIN_PROFIT_PERCENTAGE = 0.0021  # Minimum profit percentage
MAX_SYMBOL_BALANCE_USDT_EQUIV = 50
RSI_PERIOD = 11
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30

# Order Book Analysis Parameters
VOLUME_IMBALANCE_THRESHOLD = 1.5  # Adjusted for higher sensitivity
SIGNIFICANT_VOLUME_MULTIPLIER = 5  # Multiplier to identify significant volume

# Rate Limiting Parameters
MAX_REQUESTS_PER_MINUTE = 1200
RATE_LIMIT_SAFETY_FACTOR = 0.75

# API Keys
API_KEY = os.getenv('BINANCE_API_KEY')
API_SECRET = os.getenv('BINANCE_API_SECRET')
