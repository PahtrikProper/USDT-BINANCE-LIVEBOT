from config import RSI_PERIOD, RSI_OVERBOUGHT, ORDER_BOOK_DEPTH, SIGNIFICANT_VOLUME_MULTIPLIER, VOLUME_IMBALANCE_THRESHOLD, MIN_PROFIT_PERCENTAGE
import logging

logger = logging.getLogger(__name__)

def calculate_rsi(ohlcv):
    closes = [candle[4] for candle in ohlcv]
    if len(closes) < RSI_PERIOD:
        return None

    gains = [0]
    losses = [0]

    for i in range(1, len(closes)):
        change = closes[i] - closes[i - 1]
        if change > 0:
            gains.append(change)
            losses.append(0)
        else:
            gains.append(0)
            losses.append(abs(change))

    avg_gain = sum(gains[:RSI_PERIOD]) / RSI_PERIOD
    avg_loss = sum(losses[:RSI_PERIOD]) / RSI_PERIOD

    for i in range(RSI_PERIOD, len(closes)):
        avg_gain = ((avg_gain * (RSI_PERIOD - 1)) + gains[i]) / RSI_PERIOD
        avg_loss = ((avg_loss * (RSI_PERIOD - 1)) + losses[i]) / RSI_PERIOD

    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def analyze_order_book(order_book):
    asks = order_book['asks']
    bids = order_book['bids']
    
    if not asks or not bids:
        logger.warning("Not enough asks or bids in the order book for analysis.")
        return None
    
    best_ask_price, best_ask_volume = asks[0]
    best_bid_price, best_bid_volume = bids[0]
    
    total_bid_volume = sum(volume for price, volume in bids)
    total_ask_volume = sum(volume for price, volume in asks)
    volume_imbalance = total_bid_volume / total_ask_volume

    min_exit_price = best_ask_price * (1 + MIN_PROFIT_PERCENTAGE)

    market_condition = 'neutral'
    if volume_imbalance > VOLUME_IMBALANCE_THRESHOLD:
        market_condition = 'bullish'
    elif volume_imbalance < 1 / VOLUME_IMBALANCE_THRESHOLD:
        market_condition = 'bearish'

    # Identify significant sell walls and support levels
    significant_sell_walls = [ask for ask in asks if ask[1] > SIGNIFICANT_VOLUME_MULTIPLIER * best_ask_volume]
    significant_support_levels = [bid for bid in bids if bid[1] > SIGNIFICANT_VOLUME_MULTIPLIER * best_bid_volume]

    # Calculate potential profit percentage based on order book
    potential_sell_price = None
    for ask_price, ask_volume in asks:
        if ask_volume < total_bid_volume * 0.1:  # Example threshold, adjust as needed
            potential_sell_price = ask_price
            break

    # Enhance logic by considering the overall buy and sell pressure
    buy_pressure = sum(bid[1] for bid in bids[:ORDER_BOOK_DEPTH//2])
    sell_pressure = sum(ask[1] for ask in asks[:ORDER_BOOK_DEPTH//2])
    overall_pressure = buy_pressure - sell_pressure

    return {
        'best_ask_price': best_ask_price,
        'best_bid_price': best_bid_price,
        'min_exit_price': min_exit_price,
        'market_condition': market_condition,
        'significant_sell_walls': significant_sell_walls,
        'significant_support_levels': significant_support_levels,
        'potential_sell_price': potential_sell_price,
        'overall_pressure': overall_pressure
    }

def analyze_recent_trades(recent_trades):
    if not recent_trades:
        logger.warning("No recent trades to analyze.")
        return None
    
    prices = [trade['price'] for trade in recent_trades]
    average_price = sum(prices) / len(prices)
    lowest_price = min(prices)
    
    return {
        'average_price': average_price,
        'lowest_price': lowest_price,
        'recent_prices': prices
    }

def determine_best_entry_price(order_book_analysis, recent_trades_analysis, rsi):
    significant_bid_price = order_book_analysis['best_bid_price']
    average_price = recent_trades_analysis['average_price']
    lowest_price = recent_trades_analysis['lowest_price']

    # Determine best entry price as the higher of significant bid price and average recent price
    best_entry_price = max(significant_bid_price, average_price)
    
    # Ensure we're not buying at a peak or during overbought conditions
    if best_entry_price > lowest_price * 1.01 or rsi > RSI_OVERBOUGHT:  # Example threshold, adjust as needed
        best_entry_price = lowest_price

    return best_entry_price
