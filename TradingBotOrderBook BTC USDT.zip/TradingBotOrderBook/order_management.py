import time
import logging
from exchange_utils import (
    exchange,
    place_order,
    update_order_status,
    cancel_order,
    fetch_balances,
    check_open_orders,
    fetch_order_book,
    fetch_recent_trades,
    fetch_ohlcv
)
from trading_strategies import (
    analyze_order_book,
    analyze_recent_trades,
    calculate_rsi,
    determine_best_entry_price
)
from config import TRADE_INTERVAL_SECONDS, SYMBOL, MAX_SYMBOL_BALANCE_USDT_EQUIV, TRADE_AMOUNT, RSI_OVERBOUGHT, ORDER_BOOK_DEPTH, MIN_PROFIT_PERCENTAGE

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def adjust_sell_order(open_order, min_sell_price, threshold=0.0005):
    try:
        price_difference = abs(min_sell_price - open_order['price']) / open_order['price']
        if price_difference >= threshold:
            logger.info(f"Adjusting sell order: {open_order['amount']} at {min_sell_price:.8f}")
            cancel_order(open_order)
            amount_to_sell = open_order['amount']
            place_order(open_order['symbol'], 'sell', min_sell_price, amount_to_sell)
        else:
            logger.info(f"Price difference {price_difference:.4f} is less than threshold {threshold:.4f}. Not adjusting sell order.")
    except Exception as e:
        logger.error(f"Failed to adjust sell order: {e}")

def calculate_fees(symbol, side, amount, price):
    try:
        fee_info = exchange.calculate_fee(symbol, side, 'limit', amount, price, 'maker')
        return fee_info['rate']
    except Exception as e:
        logger.error(f"Failed to calculate fees: {e}")
        return 0

def live_trading(symbol):
    usdt_balance, BTC_balance = fetch_balances()
    if usdt_balance is None or BTC_balance is None:
        logger.error("Failed to fetch initial balances. Exiting.")
        return

    ohlcv = fetch_ohlcv(symbol, timeframe='15m')
    rsi = calculate_rsi(ohlcv)
    if rsi is None:
        logger.error("Failed to calculate RSI. Exiting.")
        return
    logger.info(f"Initial RSI: {rsi:.2f}")

    active_trade = None
    last_api_call_time = time.time()
    previous_market_condition = 'neutral'
    last_adjustment_time = 0  # Track last adjustment time for sell orders

    while True:
        time_since_last_call = time.time() - last_api_call_time
        if time_since_last_call < TRADE_INTERVAL_SECONDS:
            time.sleep(TRADE_INTERVAL_SECONDS - time_since_last_call)
        
        open_orders = check_open_orders(symbol)
        if open_orders:
            try:
                order_book = fetch_order_book(symbol, ORDER_BOOK_DEPTH)
                order_book_analysis = analyze_order_book(order_book)
                min_sell_price = order_book_analysis['min_exit_price']
            except Exception as e:
                logger.error(f"Failed to fetch or analyze order book: {e}")
                continue

            current_time = time.time()
            if current_time - last_adjustment_time >= 10:  # Check if 10 seconds have passed since the last adjustment
                for open_order in open_orders:
                    if open_order['side'] == 'sell':
                        adjust_sell_order(open_order, min_sell_price)
                last_adjustment_time = current_time  # Update the last adjustment time

            for open_order in open_orders:
                if open_order['side'] == 'buy' and open_order['price'] >= min_sell_price:
                    cancel_order(open_order)

            continue
        
        try:
            order_book = fetch_order_book(symbol, ORDER_BOOK_DEPTH)
            recent_trades = fetch_recent_trades(symbol)
            ohlcv = fetch_ohlcv(symbol, timeframe='15m')
            rsi = calculate_rsi(ohlcv)
            last_api_call_time = time.time()
        
            if order_book is None or recent_trades is None or rsi is None:
                logger.warning("Failed to fetch order book, recent trades, or RSI. Skipping this iteration.")
                continue

            order_book_analysis = analyze_order_book(order_book)
            recent_trades_analysis = analyze_recent_trades(recent_trades)
        
            if order_book_analysis is None or recent_trades_analysis is None:
                logger.warning("Failed to analyze order book or recent trades. Skipping this iteration.")
                continue
        
            best_entry_price = determine_best_entry_price(order_book_analysis, recent_trades_analysis, rsi)
        except Exception as e:
            logger.error(f"Error during data fetching or analysis: {e}")
            continue

        # Avoid buying if there are significant sell walls above the best entry price
        significant_sell_walls = order_book_analysis['significant_sell_walls']
        if any(wall[0] <= best_entry_price for wall in significant_sell_walls):
            logger.info("Significant sell walls detected above the best entry price. Skipping this iteration.")
            continue

        # Avoid buying during strong downtrends or overbought conditions
        if recent_trades_analysis['recent_prices'][-1] < min(recent_trades_analysis['recent_prices']) or rsi > RSI_OVERBOUGHT:
            logger.info("Strong downtrend or overbought condition detected. Skipping this iteration.")
            continue

        logger.info(f"Market condition: {order_book_analysis['market_condition']}, Best entry price: {best_entry_price:.8f}, RSI: {rsi:.2f}, Overall Pressure: {order_book_analysis['overall_pressure']:.2f}")

        symbol_balance_usdt_equiv = BTC_balance * best_entry_price

        if (previous_market_condition in ['neutral', 'bearish'] and 
            order_book_analysis['market_condition'] == 'bullish' and 
            order_book_analysis['overall_pressure'] > 0 and 
            symbol_balance_usdt_equiv < MAX_SYMBOL_BALANCE_USDT_EQUIV):
            
            # Check for potential profit
            min_exit_price = order_book_analysis['min_exit_price']
            potential_profit = (min_exit_price - best_entry_price) / best_entry_price

            logger.info(f"Best entry price: {best_entry_price}, Min exit price: {min_exit_price}, Potential profit: {potential_profit}")

            if potential_profit < MIN_PROFIT_PERCENTAGE:
                logger.info(f"Potential profit {potential_profit:.4f} is less than the minimum required {MIN_PROFIT_PERCENTAGE:.4f}. Skipping buy order.")
                continue

            if active_trade is None and usdt_balance >= TRADE_AMOUNT:
                amount_to_buy = TRADE_AMOUNT / best_entry_price
                active_trade = place_order(symbol, 'buy', best_entry_price, amount_to_buy)
                if active_trade is not None:
                    logger.info(f"Buy order placed at best entry price: {best_entry_price:.8f}")
                    usdt_balance, BTC_balance = fetch_balances()  # Refresh balances
                    logger.info(f"Updated balance after placing buy order: {usdt_balance:.2f} USDT, BTC balance: {BTC_balance:.8f}")

        if active_trade and active_trade['side'] == 'buy':
            active_trade = update_order_status(active_trade)
            if active_trade['status'] == 'closed':
                logger.info(f"Buy order filled at {active_trade['price']:.8f}")
                usdt_balance, BTC_balance = fetch_balances()  # Refresh balances
                
                logger.info("Waiting 1 second before placing the sell order.")
                time.sleep(1)
                
                min_sell_price = order_book_analysis['min_exit_price']

                # Fetch applicable fees
                sell_fee_rate = calculate_fees(symbol, 'sell', BTC_balance, min_sell_price)

                # Calculate the amount to sell considering the fees
                amount_to_sell = BTC_balance / (1 + sell_fee_rate)

                # Calculate the potential profit percentage based on the order book analysis
                potential_sell_price = order_book_analysis['potential_sell_price']
                if potential_sell_price and potential_sell_price > min_sell_price:
                    min_sell_price = potential_sell_price

                # Check if the equivalent value of the sell order is less than 50 USDT
                if amount_to_sell * min_sell_price < MAX_SYMBOL_BALANCE_USDT_EQUIV:
                    logger.info(f"Equivalent value of the sell order is less than {MAX_SYMBOL_BALANCE_USDT_EQUIV} USDT. Skipping sell order.")
                    active_trade = None
                else:
                    while True:
                        sell_order = place_order(symbol, 'sell', min_sell_price, amount_to_sell)
                        if sell_order:
                            logger.info(f"Sell order placed at price: {min_sell_price:.8f}")
                            usdt_balance, BTC_balance = fetch_balances()  # Refresh balances
                            logger.info(f"Updated BTC balance after placing sell order: {BTC_balance:.8f}")
                            break
                        else:
                            logger.error(f"Failed to place sell order. Retrying with adjusted amount.")
                            amount_to_sell *= 0.99  # Reduce the amount slightly and retry

        elif active_trade and active_trade['side'] == 'sell':
            active_trade = update_order_status(active_trade)
            if active_trade['status'] == 'closed':
                logger.info(f"Sell order filled at {active_trade['price']:.8f}")
                usdt_balance, BTC_balance = fetch_balances()  # Refresh balances
                logger.info(f"Updated balance after sell order filled: {usdt_balance:.2f} USDT, BTC balance: {BTC_balance:.8f}")
                active_trade = None

        total_value = usdt_balance + BTC_balance * best_entry_price
        logger.info(f"Current Balance: {usdt_balance:.2f} USDT, BTC Balance: {BTC_balance:.8f}, Total Value: {total_value:.2f}")
        previous_market_condition = order_book_analysis['market_condition']
