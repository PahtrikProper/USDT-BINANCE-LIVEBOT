import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configurable Parameters
SYMBOL = 'CVP/USDT'
ORDER_BOOK_DEPTH = 400
TRADE_AMOUNT = 400
TRADE_INTERVAL_SECONDS = 5
MIN_PROFIT_PERCENTAGE = 0.009  # Minimum profit percentage
MAX_SYMBOL_BALANCE_USDT_EQUIV = 50
RSI_PERIOD = 14
RSI_OVERBOUGHT = 66.8
RSI_OVERSOLD = 33.45

# Order Book Analysis Parameters
VOLUME_IMBALANCE_THRESHOLD = 1.15  # Adjusted for higher sensitivity
SIGNIFICANT_VOLUME_MULTIPLIER = 3  # Multiplier to identify significant volume

# Rate Limiting Parameters
MAX_REQUESTS_PER_MINUTE = 1100
RATE_LIMIT_SAFETY_FACTOR = 0.75

# API Keys
API_KEY = os.getenv('BINANCE_API_KEY')
API_SECRET = os.getenv('BINANCE_API_SECRET')
